#HashMap ~ Diccionarios

# 1. **
# Crear una función que cuente cuántas palabras hay en una cadena y devuelva el resultado.
# Ejemplo
# - Entrada
# Coding Dojo es el mejor bootcamp donde he hecho coding. El mejor dojo es el de Chile y esto hace que Coding Dojo sea mejor que los otros bootcamp que no tienen sede en Chile. ¡Coding es lo mejor!

# - Salida
# Número de palabras: 39

def A(cadena): 
    separador = cadena.split()
    print(separador)
A("Hola esta es la cadena de ejemplo.")

# 2. **
# Crear un algoritmo que cuente cuántas veces se repite cada palabra en una cadena y devuelva el resultado para mostrarlo.
# Ejemplo
# - Entrada
# Coding Dojo es el mejor bootcamp donde he hecho coding. El mejor dojo, es el de Chile y esto hace que Coding Dojo sea mejor que los otros bootcamp que no tienen sede en Chile. ¡Coding es lo mejor!

# - Salida
# Coding: ?
# Dojo: ?
# es: ?
# el: ?
# mejor: ?
# ...
# ...
# ...
arr = []
def B(cadena1):
    misuscula = cadena1.lower()
    separador1 = misuscula.split()
    for b in range(len(separador1)):
        palabra = separador1[b]
        repeticiones = separador1.count(separador1[b])
        print(f'{palabra} : {repeticiones}')
B(("Hola Mundo ")*3)
