#Teniendo el siguiente arreglo crear un algoritmo que permita ver el nombre y la lista de notas de los estudiantes y colocar al final de la lista el promedio de las notas:

#["Jhon", 1.2, "Carlos", 4.5, "John", 4.3, "David", 4, Jhon", 2.2, "Carlos", 4.5, "John", 3.3, "David", 4, "Jhon", 3.2, "Carlos", 4.5, "David", 4, "Jhon", 1.8, "Carlos", 4.5, "John", 4.3, "David", 4, Jhon", 2.2, "Carlos", 4.5, "John", 3.3, "David", 4, "Jhon", 3.5, "Carlos", 4.5, "David", 4, "Andres", 3.5]

#{
    #"Jhon" : [1.2, 2.2, 3.2, 1.8, 2.2, 3.5, 2.35],
    #"Carlos": ...
#}
arr1 = []
arr2 = []
def A(arr0):
    for a in range(len(arr0)):
        dato = arr0[a]
        if(type(dato)== str):
            arr1.append(arr0[a])
            x = set(arr1)
        if(type(dato) == float):
            arr2.append(arr0[a])
        if(type(dato) == int):
            arr2.append(arr0[a])
        y = arr2
    for á in arr0:
        if(á == x):
            
    #print(arr1, arr2, arr3, arr4)

A(["Jhon", 1.2, "Carlos", 4.5, "John", 4.3, "David", 4, "Jhon", 2.2, "Carlos", 4.5, "John", 3.3, "David", 4, "Jhon", 3.2, "Carlos", 4.5, "David", 4, "Jhon",
 1.8, "Carlos", 4.5, "John", 4.3, "David", 4, "Jhon", 2.2, "Carlos", 4.5, "John", 3.3, "David", 4, "Jhon", 3.5, "Carlos", 4.5, "David", 4, "Andres", 3.5])
