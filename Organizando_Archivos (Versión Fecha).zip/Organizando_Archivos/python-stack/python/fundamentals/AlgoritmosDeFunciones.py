#1
def a():
    return 5 # Esto es lo que devuelve de la función
print(a()) # Se llama la función con un print / Se resuelve a() -> 5 = 5

# EL OUTPUT ES 5 #

#2
def a():
    return 5 # Esto es lo que devuelve la función
print(a()+a()) # Se llama la función / Se resuelve a() + a() -> 5 + 5 = 10

# EL OUTPUT ES 10 #

#3
def a():
    return 5 # En este caso solo se puede usar un return; Esto es lo que devuelve la función
    return 10 # Este no se cuenta
print(a()) # Se llama la función / Se resuelve el a() -> 5 = 5

# EL RETURN ES 5 #

#4
def a():
    return 5 # Esto es lo que devuelve la función
    print(10) # Cuando hay un return, todo lo que le sigue se muere
print(a()) # Se llama la función / Se resuelve a() -> 5 = 5

# EL OUTPUT ES 5 #

#5
def a():
    print(5) # Devuelve esto en pantalla 
x = a() # Se llama la función
print(x) # La función carece de return así que tiene valor none

# EL OUTPUT ES 5, None #

#6
def a(b,c):
    print(b+c) # Se desarrolla (b+c) -> (1,2) = 3; (2,3) = 5, [3,5] se muestra en pantalla
print(a(1,2) + a(2,3)) #Se llama la función / La función carece de return así que no vuelve el [3,5]

# EL OUTPUT ES [3,5] Y LUEGO LANZA ERROR #

#7
def a(b,c):
    return str(b)+str(c) # Se devuelve (Se reemplaza b -> 2; c -> 5, pero pasan a string "2" y "5")
print(a(2,5)) # Se llama a la función / como se concatenó "2" y "5". será igual a "25"

# EL OUTPUT ES EL STRING 25 #

#8
def a(): # Desarrollamos la función 
    b = 100 # se le signa el valor 100 a b
    print(b) # se imprime b en pantalla
    if b < 10: # se muestra un condicional "si b es mnor que 10" Es verdad ¿? No 100 < 10 no se cumple
        return 5 # returna 5 no se ejecuta
    else: # si no cumple if, pasamos a else
        return 10 # se ejecta 10 al tener solo la condición de que "if no sea cierto"
    return 7 # Se acaba de ejecutar return 10, así que return 7 no se ejecuta
print(a()) # Se llama la función 

# EL OUTPUT ES [100, 10]

#9
def a(b,c):
    if b<c:# Se la condición "si b es menor que c" Es verdad ¿?... Solo para (2,3)
        # (b,c) | (2,3) -> 2<3 True | (5,3) -> 5<3 Flase | (2,3) y (5,3) son True y False respectivamente 
        return 7 # En print(a(2,3)) y solo print(a(2,3) + a(5,3)) se devuelve 7
    else: # Se cumple solo para (5,3)
        return 14 # En print(5,3) y print(a(2,3) + a(5,3))
    return 3
print(a(2,3)) # Se llama la función / --> print(7) = 7
print(a(5,3)) # Se llama la función / --> print(14) = 14
print(a(2,3) + a(5,3)) # Se llama la función / --> print(7 + a(5,3)) --> print(7+14) = 21

# EL OUTPUT ES [7,14,21]

#10
def a(b,c): # Se desarrolla
    return b+c # como b -> 3 y c -> 5; returna 3+5 = 8
    return 10 # como ya se ejecuto un return, ya no se ejecuta el return 10
print(a(3,5)) # Se llama a la función 

# EL OUTPUT ES 8

#11
b = 500 # Se define la variable b con el valor 500
print(b) # se imprime b ---> [500]
def a(): # se desarrolla la función
    b = 300 # Se define una nueva variable b con el valor 300
    print(b) # Se imprime b ---> [300]
print(b) # Se vuelve a imprimir la variable b de la línea 89 ---> [500]
a() # Se llama la función
print(b) # Se vuelve a imprimir la variable b de la línea 89 ---> [500]

# EL OUTPUT ES [500,500,100,500]

#12
b = 500 # Se define la variable b con el valor 500
print(b) # se imprime b ---> [500] Es el primer print en ejecutarse
def a(): # se desarrolla la función
    b = 300 # se define una nueva variable b dentro de la función con el valor 300
    print(b) # se imprime b ---> [300] Es el tercer print en ejecutarse
    return b # se devuelve b 
print(b) # se imprime el b de la línea 101 ---> [300] Es el segundo print en ejecutarse
a() # Se llama la función 
print(b) # se imprime b ---> [300] Es el último print en ejecutarse

# EL OUTPUT ES [500,500,300,500]

#13
b = 500 # Se define la variable con el valor 500 
print(b) # se imprime b [500] Es el primer print en ejecutarse
def a(): # se desarrolla la función
    b = 300 # se define la nueva variable b con valor 300
    print(b) # se imprime b de la función ---> [300] es el tercer print que se ejecuta
    return b # se devuelve b
print(b) # se imprime el b de la línea 114 ---> [500] es el segundo print que se ejecuta
b=a() # Se llama la función / Se iguala b con a(), a() tiene de return 300
print(b) # se imprime b ---> [300] es el cuarto print que se ejecuta 

# EL OUTPUT ES [500, 500, 300, 300]

#14
def a(): # se desarrolla la función
    print(1) # se imprime [1] es el primer print en ejecutarse
    b() # se llama b()
    print(2) # se imprime el [2] es el tercer print en ejecutarse
def b(): # se desarrolla b()
    print(3) # se imprime [3] es el segundo print en ejecutarse
a() # Se llama la función a()

# EL OUTPUT ES [1,3,2]

#15
def a(): # se desarrolla la función
    print(1) # se imprime [1] es el primer print en ejecutarse
    x = b() # se define la variable x dentro de la función y se le asigna el valor del return de b()
    print(x) # se imprime [x] ---> returna 5 de la función b() ---> [5] es el tercer print en ejecutarse
    return 10 # se devuelve [10] de la función a()
def b(): # se dearrolla la función b()
    print(3) # se imprime [3] es el segundo print en ejecutarse
    return 5 # se devuelve [5] de la función b() 
y = a() # Se le asigna el return de la función a() a la variable y returna 10 de la función a()
print(y) # se imprime [y] ---> [10] es el cuarto print en ejecutarse

# EL OUTPUT ES [1,3,5,10] #










