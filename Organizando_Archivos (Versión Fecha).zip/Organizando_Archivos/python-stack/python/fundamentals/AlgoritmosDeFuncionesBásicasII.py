#
# NOTA: YO USO ARREGLOS AL INICIO PARA QUE EL OUTPUT SE VEA EN UNA LÍNEA, O SEA EJ: [1,True,'pop',3.42]
# solo es maña mía kjsksskkjs no me gusta que se vea:
# 1
# True
# pop
# 3.42
# etc
# pero si me lo piden cambiare el formato kjskjs

print("ingrese un número")
num = 10 # Este número puede ser cambiado a conveniencia
arr = []
def I(a):
    for i in range(int(a),-1,-1):
        arr.append(i)
I(num)
print(f"su número es, {num}")
print(f"cuenta regresiva, {arr}")

#----------------------------------------------------------------------------------------------------#

arr4 = []
def O(numero1, numero2):
    print(numero1)
    return numero2
O(4,7)


#----------------------------------------------------------------------------------------------------#

arr0 = []
def function(arr0):
    print(f"la suma es, {arr0[0]+len(arr0)}")

function([3,9,5,0,3])

#----------------------------------------------------------------------------------------------------#

arr1 = []
arr2 = []
def A(arr1):
    for a in arr1:
        if(a > arr1[1]):
            arr2.append(a)
    print(len(arr2))
    print(arr2)
A([1,4,8,2,7,9,6,2])
if(len(arr2) <= 2):
    print(False)        
else:
    print(True)

#----------------------------------------------------------------------------------------------------#

arr3 = []
operador = []
print('Elija un tamaño y un valor')
def funcion(longitud,valor):
    if(longitud >= 1):
        arr3.append(longitud)
        arr3.append(valor)
        operador = str(valor)*longitud
        print(f'si se tiene, {arr3} ' + f'entonces se obtiene, {operador}')
    else: 
        print('Ingrese un número mayor que 1')
funcion(2,8) # longitud es "2", pero puede ser cambiado por cualquier número mayor o igual a 1, por otra
             # parte puede cambiar el valor que es "8" por cualquier entero

#----------------------------------------------------------------------------------------------------#




