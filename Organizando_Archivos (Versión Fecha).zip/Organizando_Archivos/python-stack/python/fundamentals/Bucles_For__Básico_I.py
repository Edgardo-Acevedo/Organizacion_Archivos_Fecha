arr = []
for a in range(0,151,1):
    arr.append(a)
print(arr)

#----------------------------------------------------------------------------------------------------#

arr1 = []
for b in range(5,1000,1):
    if(b%5==0):
        arr1.append(b)
print(arr1)

#----------------------------------------------------------------------------------------------------#

arr2 = []
for c in range(1,101,1):
    arr2.append(c)    
    if(c%5==0):
        arr2.pop()
        arr2.append("Coding")
    if(c%10==0):
        arr2.pop()
        arr2.append("Coding Dojo")
    if(c%5==0 and c%10==0):
        arr2.pop()
        arr2.append("Coding")
        arr2.append("Coding Dojo")

print(arr2)

#----------------------------------------------------------------------------------------------------#

arr3 = []
primo3 = []
sum3 = []
for d in range(1,2501,1):
    primo3 = (2 * d) - 1
    arr3.append(primo3)

sum3 = arr3[2499] * (arr3[2499] + 1)/2
print(sum3)
    
#-----------------------------------------------------------------------------------------------------#

arr4 = []
for e in range(2018,-1,-1):
   if(e%4==0):
       arr4.append(e)
print(arr4)

#-----------------------------------------------------------------------------------------------------#

lowNum = 4
highNum = 26
mult = 5
arr6 = []
for f in range(lowNum,highNum,1):
    if(f%mult==0):
        arr6.append(f)
print(arr6)