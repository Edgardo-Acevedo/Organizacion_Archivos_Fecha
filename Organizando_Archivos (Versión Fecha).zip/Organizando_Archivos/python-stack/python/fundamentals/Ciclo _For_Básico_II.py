#----------------------------------------------------------------------------------------------------#
# EN LOS EJERCICIOS PERDÓN POR LOS SÍMBOLOS QUE USO DE ITERADORES XD es que me gustan 
#----------------------------------------------------------------------------------------------------#

arr1 = []
def A(arr0):
    for a in arr0:
        if(a>0):
            á = arr0.index(a)
            arr1.append(á)
            for æ in arr1:
                arr0[æ] = 'big'
    print(arr0)
A([3, -2, 6, -3, -7, 0, 9])

#----------------------------------------------------------------------------------------------------#
# LOS VALORES DE LA FUNCIÓN C() PUEDEN SER ALTERADOS A GUSTO
#----------------------------------------------------------------------------------------------------#

arr3 = []
def C(arr2):
    for c in arr2:
        if(c>0):
            arr3.append(c)
            ć = len(arr3)
            arr2[-1] = ć
    print(arr2)
C([3,8,-3,5,6,-3,0,1])

#----------------------------------------------------------------------------------------------------#
# ESTE ES MEDIO SENCILLO, ES UNA DE LOS PRIMEROS ALGORITMOS QUE APRENDIMOS EN EL CURSO
#----------------------------------------------------------------------------------------------------#

def D(arr4):
    arr5 = 0
    for d in arr4:
        arr5 = arr5 + d
    print(arr5)
D([4,5,-2,5,-7,2,10])

#----------------------------------------------------------------------------------------------------#
# ESTE ES PARECIDO AL ANTERIOR SOLO QUE SUMAN LOS VALORES Y LUEGO SE DIVIDEN POR CANTIDAD DE ELEMENTOS
#----------------------------------------------------------------------------------------------------#

def E(arr6):
    arr7 = 0
    for e in arr6:
        arr7 = arr7 + e
    arr7 = arr7/len(arr6)
    print(arr7)
E([4,5,3,5,7])

#----------------------------------------------------------------------------------------------------#
# ESTE ES FACILISIMO 
#----------------------------------------------------------------------------------------------------#

def F(arr8):
    print(len(arr8))
F([3,6,'Coding',True])

#----------------------------------------------------------------------------------------------------#
# ESTA TAMBIÉN FUE UNA DE LAS PRIMERAS QUE APRENDIMOS 
#----------------------------------------------------------------------------------------------------#

def G(arr9):
    if(len(arr9)!=0):
        print(min(arr9))
    else:
        print(False)
G([3,10,4.6,-2])
G([])

#----------------------------------------------------------------------------------------------------#
# LO MISMO, PERO AL REVÉS
#----------------------------------------------------------------------------------------------------#

def H(arr10):
    if(len(arr10)!=0):
        print(max(arr10))
    else:
        print(False)
H([-230,10.4,42.6,22])
H([])

#----------------------------------------------------------------------------------------------------#
# ESTE ES MEDIO LARGO, PERO ES LA UNIÓN DE LOS ANTERIORES USANDO UN DICCIONARIO
#----------------------------------------------------------------------------------------------------#
 
def I(arr10):
    suma = 0
    for i in arr10:
        suma = suma + i
    SumaTotal = suma
    Promedio = SumaTotal/len(arr10)
    Minimo = min(arr10)
    Maximo = max(arr10)
    Longitud = len(arr10)
    diccionario = {
        'SumaTotal' : SumaTotal,
        'Promedio'  : Promedio,
        'Minimo'    : Minimo,
        'Maximo'    : Maximo,
        'Longitud'  : Longitud,
        }
    print(diccionario)
I([3,6,-2,1,10,-6])

#----------------------------------------------------------------------------------------------------#
# ESTE ES MUY ÚTIL PARA LAS ENTREVISTAS COMO DIJIERON, PERO TAMBIÉN ES SENCILLO
#----------------------------------------------------------------------------------------------------#

def J(arr11):
    arr11.reverse()    
    print(arr11)
J([2,'Dojo',0.4,-3,True])