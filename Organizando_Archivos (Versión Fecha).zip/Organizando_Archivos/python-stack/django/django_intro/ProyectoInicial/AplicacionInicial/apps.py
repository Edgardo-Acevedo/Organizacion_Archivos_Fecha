from django.apps import AppConfig


class AplicacioninicialConfig(AppConfig):
    name = 'AplicacionInicial'
