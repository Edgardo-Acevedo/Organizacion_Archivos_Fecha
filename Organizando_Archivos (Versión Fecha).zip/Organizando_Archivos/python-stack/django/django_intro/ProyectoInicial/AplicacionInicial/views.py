
from django import http
from django.shortcuts import HttpResponse
from django.shortcuts import render, HttpResponse
from django.shortcuts import HttpResponse, redirect

#----------------------------------------------------------------------------------------------------------------------------------------#

def root(request):
    return redirect('http://localhost:8000/blogs/')

def Index(request):
    return HttpResponse('Estos son todos los blogs') 
    
#----------------------------------------------------------------------------------------------------------------------------------------#

def new(request):
    print('placeholder para mostrar un nuevo formulario')
    return render(request, "Formulario.html") 

#----------------------------------------------------------------------------------------------------------------------------------------#

def create(request):
    return redirect('http://localhost:8000/')

#----------------------------------------------------------------------------------------------------------------------------------------#

def show(request, number):
    return HttpResponse(f'placeholder para mostrar el blog número, {number}')

#----------------------------------------------------------------------------------------------------------------------------------------#

def edit(request, number):
    return HttpResponse(f'placeholder para editar el blog número, {number}')

#----------------------------------------------------------------------------------------------------------------------------------------#

def destroy(request, number):
    return redirect('http://localhost:8000/blogs/')


