from django import http
from django.shortcuts import HttpResponse
from django.shortcuts import render, HttpResponse
from django.shortcuts import HttpResponse, redirect
from time import gmtime, strftime
from datetime import datetime
    
def index(request):
    time = datetime.now()
    fecha = time.strftime("%Y-%m-%d %H:%M:%S %p")
    context = {
        "mensaje" : 'Fecha horaria de Chile',
        "fecha" : f"{fecha}",
        "time" : f"{time}",
    }
    return render(request, 'index.html', context)
