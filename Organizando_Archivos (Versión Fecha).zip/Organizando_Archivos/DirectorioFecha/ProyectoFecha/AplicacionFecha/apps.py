from django.apps import AppConfig


class AplicacionfechaConfig(AppConfig):
    name = 'AplicacionFecha'
